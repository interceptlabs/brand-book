Intercept brand assets
interceptgroup.com — Fresh thinking starts here.

logos/lockups/  — 14 SVG lockups (baseline + centered × Flarepop/Coolsweep/Wiretree × Carbon/Halo backgrounds)
logos/mark/     — the Intercept triangle mark, standalone SVG
logos/wordmark/ — wordmark-only SVG
logos/raster/   — 5600px PNG lockups (on-carbon + transparent)
logos/vector-eps/ — EPS vector source for print
tokens/         — tokens.css (color, type, spacing as CSS custom properties)

Typefaces (free, Google Fonts): Instrument Sans (display), Inter (body), Geist Mono (mono).
Live brand center: https://interceptlabs.github.io/brand-book/
