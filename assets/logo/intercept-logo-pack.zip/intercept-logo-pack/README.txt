Intercept logo pack
===================

12 SVG lockup variants — 2 alignments × 3 channels × 2 wordmark colours.

Alignment
  baseline  — Brand OS §8.5 canonical (triangle base on wordmark baseline)
  centered  — Wordmark lifted to visually centre against the triangle

Channels (locked semantic roles)
  flarepop  — primary    #FF00E5
  coolsweep — secondary  #1A7AFF
  wiretree  — tertiary   #00D862

Wordmark colour
  on-carbon — Halo white wordmark for dark backgrounds
  on-halo   — Carbon dark wordmark for light backgrounds

Master files (uncoloured)
  intercept-lockup-baseline.svg
  intercept-lockup-centered.svg
  Intercept_logo_fritz_lockup_left_right.eps  (universal vector source)

Aspect ratio: 4.25 : 1. Sanitized — no preserveAspectRatio='none'.
Triangle base aligns to wordmark baseline (Group 1 transform corrects
the Figma export's descender offset).

Brand rule: never recolour outside the locked channel set. Never
stretch, never recreate the wordmark in CSS. Real SVG/EPS only.
